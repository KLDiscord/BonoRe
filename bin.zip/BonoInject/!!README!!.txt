보노 인젝터 v.1.0 by KL ( Bono X,V2,Re의 개발자 ) 
다운로드 : https://bonov2.netlify.app

netlify.app 사용해서 죄송합니다. 제가 그지라서 그럽니다.
https://www.roblox.com/game-pass/24932294/Donate 게임페스좀 사서 후원해주세요

감사합니다 :D !

Bono Injector v.1.0 by KL_Offical (Dev of BonoV2)
download bono v2 at https://bonov2.netlify.app

sry for "netlify.app" cuz i'm poor :(
Donate me at - https://www.roblox.com/game-pass/24932294/Donate

Thanks :D !